to run the CODE V part:
1. copy *.seq to the CODE V user directory typically: c:\CODEV\CVUSER
2. open CODE V
3. In the Command Window type 
   tow in emw-export
